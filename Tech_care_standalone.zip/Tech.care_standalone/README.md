# Tech.Care Dashboard

## How to open
Just double-click index.html — it works directly in any browser, no server needed.

All CSS and JavaScript are bundled into the single index.html file.
Source files are in the /src folder for review.
